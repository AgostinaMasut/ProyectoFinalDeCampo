﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LolaApp.Core.Attributes
{
    public class UpsertItemAttribute : Attribute
    {
    }
}
