﻿using LolaApp.Core;

namespace LolaApp.Entities
{
    public class TipoDeUsario : EntityBase
    {
        public int Id { get; set; }

        public string Denominación { get; set; }

    }

}
