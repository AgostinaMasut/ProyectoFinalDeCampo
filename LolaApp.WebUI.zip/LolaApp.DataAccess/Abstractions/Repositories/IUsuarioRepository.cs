﻿using LolaApp.Entities;
using LolaApp.Services.Abstractions;

namespace LolaApp.DataAccess.Replositories
{
    public interface IUsuarioRepository : IRepositoryBase<Usuario>
    {

    }
}
