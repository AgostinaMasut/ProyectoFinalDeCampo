﻿namespace LolaApp.WebUI.Models
{
    public class ModelBase
    {

    }
}